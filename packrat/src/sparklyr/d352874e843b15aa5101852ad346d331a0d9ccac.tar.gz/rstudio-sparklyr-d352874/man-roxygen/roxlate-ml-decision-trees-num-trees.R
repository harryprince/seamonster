#' @param num.trees Number of trees to train (>= 1).
