#' @param ml.options Optional arguments, used to affect the model generated. See
#'   \code{\link{ml_options}} for more details.
