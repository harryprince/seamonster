#' @param features The name of features (terms) to use for the model fit.

