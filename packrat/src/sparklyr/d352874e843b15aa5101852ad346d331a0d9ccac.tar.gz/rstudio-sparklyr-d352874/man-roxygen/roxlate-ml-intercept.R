#' @param intercept Boolean; should the model be fit with an intercept term?

