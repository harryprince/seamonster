
.globals <- new.env(parent = emptyenv())
.globals$extension_packages <- character()

