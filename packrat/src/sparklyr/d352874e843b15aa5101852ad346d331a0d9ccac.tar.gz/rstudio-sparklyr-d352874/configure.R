#!/usr/bin/env Rscript
library(sparklyr)
sparklyr::compile_package_jars()
