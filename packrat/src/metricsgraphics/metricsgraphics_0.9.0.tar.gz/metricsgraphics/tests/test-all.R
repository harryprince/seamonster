library(testthat)
test_check("metricsgraphics")
